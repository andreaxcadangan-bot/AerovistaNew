package com.aerovistanew.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
