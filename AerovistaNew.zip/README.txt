AerovistaNew Flutter project

Asset paths have been corrected to match the files in the ZIP:
- assets/index.html
- assets/aerovistanew-background.mp4
- assets/qris.png
- assets/about-you-x-multo.mp3

Build: flutter pub get && flutter build apk --release
Note: this fixes the missing-asset error reported by the builder; a full Release build has not been run here.


Build workflow now produces both a debug/base testing APK and a release APK. See README-BUILD-ONLINE.txt.
\nFirebase foundation added: see FIREBASE_SETUP.md. No live Firebase project or credentials are included.\n


Updated: workflow now builds one release APK artifact named AerovistaNew.apk, without backend API. See README-BUILD-ONLINE.txt.
