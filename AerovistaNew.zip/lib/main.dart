import 'package:flutter/material.dart';
import 'firebase_service.dart';
import 'package:webview_flutter/webview_flutter.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await FirebaseService.initializeIfConfigured();
  runApp(const AerovistaNewApp());
}

class AerovistaNewApp extends StatelessWidget {
  const AerovistaNewApp({super.key});
  @override
  Widget build(BuildContext context) => const MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'AerovistaNew',
    home: AerovistaNewHome(),
  );
}

class AerovistaNewHome extends StatefulWidget {
  const AerovistaNewHome({super.key});
  @override
  State<AerovistaNewHome> createState() => _AerovistaNewHomeState();
}

class _AerovistaNewHomeState extends State<AerovistaNewHome> {
  late final WebViewController controller;
  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF080B14))
      ..setNavigationDelegate(NavigationDelegate())
      ..loadFlutterAsset('assets/index.html');
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF080B14),
    body: SafeArea(child: WebViewWidget(controller: controller)),
  );
}
